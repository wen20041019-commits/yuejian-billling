import AsyncStorage from '@react-native-async-storage/async-storage';
import { Ionicons } from '@expo/vector-icons';
import { StatusBar } from 'expo-status-bar';
import React, { useEffect, useMemo, useState } from 'react';
import {
  Alert,
  AppState,
  KeyboardAvoidingView,
  NativeModules,
  Platform,
  Pressable,
  SafeAreaView,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
} from 'react-native';

type Tab = 'home' | 'add' | 'summary';
type Category = '餐饮' | '交通' | '购物' | '居住' | '娱乐' | '其他';

type Transaction = {
  id: string;
  amount: number;
  category: Category;
  note: string;
  date: string;
  createdAt: number;
  source?: 'manual' | 'wechat' | 'alipay';
};

const PaymentCapture = NativeModules.PaymentCapture as undefined | {
  openNotificationSettings: () => void;
  isEnabled: () => Promise<boolean>;
  drainPending: () => Promise<string>;
};

const TX_KEY = 'qingzhang.transactions.v1';
const BUDGET_KEY = 'qingzhang.monthlyBudget.v1';
const DEFAULT_BUDGET = 3000;

const categories: { name: Category; icon: keyof typeof Ionicons.glyphMap; color: string }[] = [
  { name: '餐饮', icon: 'restaurant-outline', color: '#E6794E' },
  { name: '交通', icon: 'bus-outline', color: '#4F83CC' },
  { name: '购物', icon: 'bag-handle-outline', color: '#A66BCB' },
  { name: '居住', icon: 'home-outline', color: '#C59138' },
  { name: '娱乐', icon: 'game-controller-outline', color: '#43A17F' },
  { name: '其他', icon: 'ellipsis-horizontal-outline', color: '#7A827D' },
];

const money = (value: number) =>
  value.toLocaleString('zh-CN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

const localDate = (date = new Date()) => {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
};

const currentMonth = () => localDate().slice(0, 7);

export default function App() {
  const [tab, setTab] = useState<Tab>('home');
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [budget, setBudget] = useState(DEFAULT_BUDGET);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    Promise.all([AsyncStorage.getItem(TX_KEY), AsyncStorage.getItem(BUDGET_KEY)])
      .then(([savedTx, savedBudget]) => {
        if (savedTx) setTransactions(JSON.parse(savedTx));
        if (savedBudget && Number(savedBudget) > 0) setBudget(Number(savedBudget));
      })
      .catch(() => Alert.alert('读取失败', '本地数据暂时无法读取，请重新打开应用。'))
      .finally(() => setReady(true));
  }, []);

  useEffect(() => {
    if (!ready || !PaymentCapture) return;
    const syncPayments = async () => {
      try {
        const payload = await PaymentCapture.drainPending();
        const incoming = JSON.parse(payload) as Transaction[];
        if (!incoming.length) return;
        setTransactions((current) => {
          const known = new Set(current.map((tx) => tx.id));
          const next = [...incoming.filter((tx) => !known.has(tx.id)), ...current];
          AsyncStorage.setItem(TX_KEY, JSON.stringify(next));
          return next;
        });
      } catch { /* A malformed payment notification should never block manual accounting. */ }
    };
    syncPayments();
    const listener = AppState.addEventListener('change', (state) => { if (state === 'active') syncPayments(); });
    return () => listener.remove();
  }, [ready]);

  const saveTransactions = async (next: Transaction[]) => {
    setTransactions(next);
    await AsyncStorage.setItem(TX_KEY, JSON.stringify(next));
  };

  const addTransaction = async (item: Omit<Transaction, 'id' | 'createdAt'>) => {
    const next = [{ ...item, id: `${Date.now()}-${Math.random()}`, createdAt: Date.now() }, ...transactions];
    await saveTransactions(next);
    setTab('home');
  };

  const removeTransaction = (item: Transaction) => {
    Alert.alert('删除这笔记录？', `${item.category}  ¥${money(item.amount)}`, [
      { text: '取消', style: 'cancel' },
      {
        text: '删除',
        style: 'destructive',
        onPress: () => saveTransactions(transactions.filter((tx) => tx.id !== item.id)),
      },
    ]);
  };

  const saveBudget = async (next: number) => {
    setBudget(next);
    await AsyncStorage.setItem(BUDGET_KEY, String(next));
  };

  if (!ready) {
    return (
      <SafeAreaView style={styles.loading}>
        <View style={styles.logo}><Ionicons name="wallet-outline" size={28} color="#FFF" /></View>
        <Text style={styles.loadingText}>轻账</Text>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.safe}>
      <StatusBar style="dark" />
      <View style={styles.screen}>
        {tab === 'home' && <Home transactions={transactions} budget={budget} onDelete={removeTransaction} />}
        {tab === 'add' && <Add onSubmit={addTransaction} />}
        {tab === 'summary' && <Summary transactions={transactions} budget={budget} onBudget={saveBudget} />}
      </View>
      <Nav active={tab} onChange={setTab} />
    </SafeAreaView>
  );
}

function Header({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <View style={styles.header}>
      <Text style={styles.eyebrow}>{eyebrow}</Text>
      <Text style={styles.title}>{title}</Text>
    </View>
  );
}

function Home({ transactions, budget, onDelete }: { transactions: Transaction[]; budget: number; onDelete: (tx: Transaction) => void }) {
  const monthly = transactions.filter((tx) => tx.date.startsWith(currentMonth()));
  const spent = monthly.reduce((sum, tx) => sum + tx.amount, 0);
  const ratio = budget > 0 ? spent / budget : 0;
  const remaining = budget - spent;
  const now = new Date();
  const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
  const daysLeft = Math.max(1, daysInMonth - now.getDate() + 1);
  const level = ratio >= 1 ? 'over' : ratio >= 0.8 ? 'warn' : 'safe';

  return (
    <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <Header eyebrow={`${now.getMonth() + 1} 月账本`} title="今天，花得明白一点。" />
      <View style={styles.hero}>
        <View style={styles.heroTop}>
          <View>
            <Text style={styles.heroLabel}>本月已支出</Text>
            <Text style={styles.heroAmount}><Text style={styles.currency}>¥</Text>{money(spent)}</Text>
          </View>
          <View style={[styles.badge, level === 'over' ? styles.badgeOver : level === 'warn' ? styles.badgeWarn : styles.badgeSafe]}>
            <Text style={styles.badgeText}>{level === 'over' ? '已超额' : level === 'warn' ? '接近预算' : '预算正常'}</Text>
          </View>
        </View>
        <View style={styles.track}><View style={[styles.fill, { width: `${Math.min(ratio * 100, 100)}%` }, level === 'over' && styles.fillOver, level === 'warn' && styles.fillWarn]} /></View>
        <View style={styles.heroFoot}>
          <Text style={styles.heroMeta}>预算 ¥{money(budget)}</Text>
          <Text style={styles.heroMeta}>{Math.round(ratio * 100)}%</Text>
        </View>
      </View>

      <View style={[styles.notice, level === 'over' && styles.noticeOver, level === 'warn' && styles.noticeWarn]}>
        <Ionicons name={level === 'over' ? 'alert-circle' : level === 'warn' ? 'warning' : 'leaf'} size={22} color={level === 'over' ? '#B54135' : level === 'warn' ? '#9A6817' : '#276454'} />
        <View style={styles.noticeCopy}>
          <Text style={styles.noticeTitle}>{level === 'over' ? `本月已超支 ¥${money(Math.abs(remaining))}` : `本月还可用 ¥${money(Math.max(remaining, 0))}`}</Text>
          <Text style={styles.noticeText}>{level === 'over' ? '建议暂停非必要支出，新的月份会自动重新统计。' : `剩余 ${daysLeft} 天，平均每天可用 ¥${money(Math.max(remaining, 0) / daysLeft)}。`}</Text>
        </View>
      </View>

      <View style={styles.sectionHead}>
        <Text style={styles.sectionTitle}>最近记录</Text>
        <Text style={styles.sectionHint}>长按可删除</Text>
      </View>
      {monthly.length === 0 ? (
        <View style={styles.empty}>
          <View style={styles.emptyIcon}><Ionicons name="receipt-outline" size={30} color="#557168" /></View>
          <Text style={styles.emptyTitle}>这个月还没有记录</Text>
          <Text style={styles.emptyText}>点下方“记一笔”，几秒就能完成。</Text>
        </View>
      ) : monthly.slice(0, 12).map((tx) => <TransactionRow key={tx.id} item={tx} onLongPress={() => onDelete(tx)} />)}
    </ScrollView>
  );
}

function TransactionRow({ item, onLongPress }: { item: Transaction; onLongPress: () => void }) {
  const meta = categories.find((cat) => cat.name === item.category) ?? categories[5]!;
  return (
    <Pressable onLongPress={onLongPress} style={({ pressed }) => [styles.txRow, pressed && { opacity: 0.65 }]}>
      <View style={[styles.txIcon, { backgroundColor: `${meta.color}1F` }]}><Ionicons name={meta.icon} size={21} color={meta.color} /></View>
      <View style={styles.txCopy}>
        <Text style={styles.txTitle}>{item.note || item.category}</Text>
        <Text style={styles.txMeta}>{item.category} · {item.date.slice(5).replace('-', '月')}日{item.source && item.source !== 'manual' ? ` · ${item.source === 'wechat' ? '微信' : '支付宝'}` : ''}</Text>
      </View>
      <Text style={styles.txAmount}>−¥{money(item.amount)}</Text>
    </Pressable>
  );
}

function Add({ onSubmit }: { onSubmit: (item: Omit<Transaction, 'id' | 'createdAt'>) => Promise<void> }) {
  const [amount, setAmount] = useState('');
  const [category, setCategory] = useState<Category>('餐饮');
  const [note, setNote] = useState('');
  const [date, setDate] = useState(localDate());
  const [saving, setSaving] = useState(false);

  const submit = async () => {
    const value = Number(amount.replace(',', '.'));
    if (!Number.isFinite(value) || value <= 0) return Alert.alert('金额不对', '请输入大于 0 的支出金额。');
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date) || Number.isNaN(new Date(`${date}T00:00:00`).getTime())) return Alert.alert('日期不对', '请按 2026-08-31 的格式输入日期。');
    setSaving(true);
    try {
      await onSubmit({ amount: Math.round(value * 100) / 100, category, note: note.trim(), date });
      setAmount(''); setNote(''); setDate(localDate());
    } catch { Alert.alert('保存失败', '这笔记录没有保存，请再试一次。'); }
    finally { setSaving(false); }
  };

  return (
    <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
      <ScrollView contentContainerStyle={styles.scroll} keyboardShouldPersistTaps="handled" showsVerticalScrollIndicator={false}>
        <Header eyebrow="快速记账" title="这笔钱，花在哪儿？" />
        <View style={styles.amountCard}>
          <Text style={styles.inputLabel}>支出金额</Text>
          <View style={styles.amountLine}><Text style={styles.bigCurrency}>¥</Text><TextInput value={amount} onChangeText={setAmount} placeholder="0.00" placeholderTextColor="#B7BDB7" keyboardType="decimal-pad" autoFocus style={styles.amountInput} /></View>
        </View>
        <Text style={styles.formLabel}>选择分类</Text>
        <View style={styles.categoryGrid}>
          {categories.map((item) => {
            const selected = category === item.name;
            return <Pressable key={item.name} onPress={() => setCategory(item.name)} style={[styles.category, selected && styles.categorySelected]}>
              <View style={[styles.categoryIcon, { backgroundColor: `${item.color}18` }]}><Ionicons name={item.icon} size={23} color={item.color} /></View>
              <Text style={[styles.categoryText, selected && styles.categoryTextSelected]}>{item.name}</Text>
              {selected && <View style={styles.check}><Ionicons name="checkmark" size={12} color="#FFF" /></View>}
            </Pressable>;
          })}
        </View>
        <Text style={styles.formLabel}>补充信息</Text>
        <View style={styles.field}><Ionicons name="create-outline" size={21} color="#75817B" /><TextInput value={note} onChangeText={setNote} placeholder="备注（选填）" placeholderTextColor="#9CA49F" maxLength={30} style={styles.fieldInput} /></View>
        <View style={styles.field}><Ionicons name="calendar-outline" size={21} color="#75817B" /><TextInput value={date} onChangeText={setDate} placeholder="YYYY-MM-DD" placeholderTextColor="#9CA49F" keyboardType="numbers-and-punctuation" maxLength={10} style={styles.fieldInput} /></View>
        <Pressable disabled={saving} onPress={submit} style={({ pressed }) => [styles.primary, pressed && { opacity: 0.85 }, saving && { opacity: 0.55 }]}>
          <Text style={styles.primaryText}>{saving ? '保存中…' : '记下这笔'}</Text><Ionicons name="arrow-forward" size={20} color="#FFF" />
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

function Summary({ transactions, budget, onBudget }: { transactions: Transaction[]; budget: number; onBudget: (value: number) => Promise<void> }) {
  const [editing, setEditing] = useState(false);
  const [budgetInput, setBudgetInput] = useState(String(budget));
  const [captureEnabled, setCaptureEnabled] = useState(false);
  const monthly = transactions.filter((tx) => tx.date.startsWith(currentMonth()));
  const spent = monthly.reduce((sum, tx) => sum + tx.amount, 0);
  const grouped = useMemo(() => categories.map((cat) => ({ ...cat, value: monthly.filter((tx) => tx.category === cat.name).reduce((sum, tx) => sum + tx.amount, 0) })).sort((a, b) => b.value - a.value), [monthly]);
  const max = Math.max(...grouped.map((item) => item.value), 1);
  const average = new Date().getDate() ? spent / new Date().getDate() : 0;
  const largest = grouped.find((item) => item.value > 0);

  useEffect(() => {
    PaymentCapture?.isEnabled().then(setCaptureEnabled).catch(() => setCaptureEnabled(false));
    const listener = AppState.addEventListener('change', (state) => {
      if (state === 'active') PaymentCapture?.isEnabled().then(setCaptureEnabled).catch(() => setCaptureEnabled(false));
    });
    return () => listener.remove();
  }, []);

  const submitBudget = async () => {
    const value = Number(budgetInput);
    if (!Number.isFinite(value) || value <= 0) return Alert.alert('预算不对', '请输入大于 0 的月预算。');
    await onBudget(Math.round(value * 100) / 100);
    setEditing(false);
  };

  return (
    <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
      <Header eyebrow={`${new Date().getMonth() + 1} 月总结`} title="钱都去了哪里？" />
      <View style={styles.statsRow}>
        <View style={styles.stat}><Text style={styles.statLabel}>本月支出</Text><Text style={styles.statValue}>¥{money(spent)}</Text></View>
        <View style={styles.stat}><Text style={styles.statLabel}>日均支出</Text><Text style={styles.statValue}>¥{money(average)}</Text></View>
      </View>
      <View style={styles.budgetBox}>
        <View><Text style={styles.budgetLabel}>每月预算</Text><Text style={styles.budgetValue}>¥{money(budget)}</Text></View>
        <Pressable onPress={() => { setBudgetInput(String(budget)); setEditing(!editing); }} style={styles.editButton}><Ionicons name="pencil" size={15} color="#285E50" /><Text style={styles.editText}>调整</Text></Pressable>
      </View>
      {editing && <View style={styles.budgetEdit}><TextInput value={budgetInput} onChangeText={setBudgetInput} keyboardType="decimal-pad" selectTextOnFocus style={styles.budgetInput} /><Pressable onPress={submitBudget} style={styles.saveSmall}><Text style={styles.saveSmallText}>保存</Text></Pressable></View>}

      <View style={styles.connectCard}>
        <View style={styles.connectHead}>
          <View style={[styles.connectStatus, captureEnabled && styles.connectStatusOn]}><View style={[styles.statusDot, captureEnabled && styles.statusDotOn]} /><Text style={[styles.connectStatusText, captureEnabled && styles.connectStatusTextOn]}>{captureEnabled ? '自动记账已开启' : '自动记账未开启'}</Text></View>
          <Ionicons name="shield-checkmark-outline" size={20} color="#668078" />
        </View>
        <Text style={styles.connectTitle}>连接微信与支付宝</Text>
        <Text style={styles.connectText}>开启通知使用权后，新的付款通知会自动记入账本。不会读取聊天，也不需要账号密码。</Text>
        <View style={styles.payRows}>
          <View style={styles.payItem}><View style={[styles.payIcon, { backgroundColor: '#E9F7EE' }]}><Ionicons name="chatbubble-ellipses" size={19} color="#18A957" /></View><Text style={styles.payName}>微信支付</Text><Text style={styles.payTag}>新付款</Text></View>
          <View style={styles.payItem}><View style={[styles.payIcon, { backgroundColor: '#EAF4FE' }]}><Ionicons name="scan" size={19} color="#1677FF" /></View><Text style={styles.payName}>支付宝</Text><Text style={styles.payTag}>新付款</Text></View>
        </View>
        <Pressable onPress={() => PaymentCapture?.openNotificationSettings()} style={({ pressed }) => [styles.connectButton, pressed && { opacity: 0.82 }]}><Text style={styles.connectButtonText}>{captureEnabled ? '管理通知使用权' : '开启自动记账'}</Text><Ionicons name="chevron-forward" size={17} color="#FFF" /></Pressable>
      </View>

      <View style={styles.sectionHead}><Text style={styles.sectionTitle}>分类占比</Text><Text style={styles.sectionHint}>{monthly.length} 笔记录</Text></View>
      <View style={styles.chartCard}>
        {grouped.map((item) => (
          <View key={item.name} style={styles.barRow}>
            <View style={styles.barLabel}><View style={[styles.dot, { backgroundColor: item.color }]} /><Text style={styles.barName}>{item.name}</Text></View>
            <View style={styles.barTrack}><View style={[styles.barFill, { width: `${(item.value / max) * 100}%`, backgroundColor: item.color }]} /></View>
            <Text style={styles.barValue}>¥{money(item.value)}</Text>
          </View>
        ))}
      </View>
      <View style={styles.insight}>
        <Ionicons name="sparkles-outline" size={23} color="#285E50" />
        <View style={styles.noticeCopy}><Text style={styles.noticeTitle}>本月小结</Text><Text style={styles.noticeText}>{largest ? `目前花费最多的是${largest.name}，共 ¥${money(largest.value)}，占本月支出的 ${Math.round((largest.value / spent) * 100)}%。` : '还没有支出记录。记下第一笔后，这里会自动生成总结。'}</Text></View>
      </View>
    </ScrollView>
  );
}

function Nav({ active, onChange }: { active: Tab; onChange: (tab: Tab) => void }) {
  const items: { key: Tab; label: string; icon: keyof typeof Ionicons.glyphMap; activeIcon: keyof typeof Ionicons.glyphMap }[] = [
    { key: 'home', label: '账本', icon: 'receipt-outline', activeIcon: 'receipt' },
    { key: 'add', label: '记一笔', icon: 'add', activeIcon: 'add' },
    { key: 'summary', label: '总结', icon: 'pie-chart-outline', activeIcon: 'pie-chart' },
  ];
  return <View style={styles.nav}>{items.map((item) => {
    const selected = active === item.key;
    if (item.key === 'add') return <Pressable key={item.key} onPress={() => onChange(item.key)} style={styles.addNav}><Ionicons name="add" size={30} color="#FFF" /><Text style={styles.addNavText}>{item.label}</Text></Pressable>;
    return <Pressable key={item.key} onPress={() => onChange(item.key)} style={styles.navItem}><Ionicons name={selected ? item.activeIcon : item.icon} size={22} color={selected ? '#214E42' : '#8A948F'} /><Text style={[styles.navText, selected && styles.navTextActive]}>{item.label}</Text></Pressable>;
  })}</View>;
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#F5F6F0' }, screen: { flex: 1 }, scroll: { paddingHorizontal: 20, paddingTop: Platform.OS === 'android' ? 40 : 20, paddingBottom: 34 },
  loading: { flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F5F6F0' }, logo: { width: 58, height: 58, borderRadius: 20, backgroundColor: '#214E42', alignItems: 'center', justifyContent: 'center' }, loadingText: { marginTop: 13, fontSize: 20, fontWeight: '800', color: '#163D33' },
  header: { marginBottom: 22 }, eyebrow: { color: '#6E7B75', fontSize: 13, fontWeight: '700', letterSpacing: 1.4, marginBottom: 7 }, title: { color: '#183D34', fontSize: 28, fontWeight: '800', letterSpacing: -0.7 },
  hero: { backgroundColor: '#183F35', padding: 21, borderRadius: 24, shadowColor: '#14372E', shadowOffset: { width: 0, height: 9 }, shadowOpacity: 0.17, shadowRadius: 16, elevation: 5 }, heroTop: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start' }, heroLabel: { color: '#BED0C9', fontSize: 13, fontWeight: '600' }, heroAmount: { color: '#FFF', fontSize: 33, fontWeight: '800', marginTop: 5, letterSpacing: -1 }, currency: { fontSize: 20, color: '#DDE9E4' }, badge: { paddingHorizontal: 10, paddingVertical: 6, borderRadius: 99 }, badgeSafe: { backgroundColor: '#3C685B' }, badgeWarn: { backgroundColor: '#8D6D2C' }, badgeOver: { backgroundColor: '#9E473E' }, badgeText: { color: '#FFF', fontSize: 11, fontWeight: '700' }, track: { height: 8, backgroundColor: '#365C51', borderRadius: 99, overflow: 'hidden', marginTop: 20 }, fill: { height: '100%', backgroundColor: '#87B5A6', borderRadius: 99 }, fillWarn: { backgroundColor: '#E8B75E' }, fillOver: { backgroundColor: '#E47B6E' }, heroFoot: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 9 }, heroMeta: { color: '#B8CBC4', fontSize: 12 },
  notice: { flexDirection: 'row', backgroundColor: '#E5EFEA', borderRadius: 18, padding: 16, marginTop: 16, borderWidth: 1, borderColor: '#D1E3DB' }, noticeWarn: { backgroundColor: '#FFF4D9', borderColor: '#F2E0B1' }, noticeOver: { backgroundColor: '#FBE6E3', borderColor: '#F1CFCA' }, noticeCopy: { flex: 1, marginLeft: 11 }, noticeTitle: { fontSize: 14, fontWeight: '800', color: '#284B41', marginBottom: 4 }, noticeText: { color: '#66736D', fontSize: 12.5, lineHeight: 19 },
  sectionHead: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 27, marginBottom: 11 }, sectionTitle: { fontSize: 17, fontWeight: '800', color: '#1E4138' }, sectionHint: { color: '#8B958F', fontSize: 12 },
  empty: { backgroundColor: '#FFF', borderRadius: 20, alignItems: 'center', padding: 27, borderWidth: 1, borderColor: '#E9EBE5' }, emptyIcon: { width: 53, height: 53, borderRadius: 18, backgroundColor: '#ECF1ED', alignItems: 'center', justifyContent: 'center' }, emptyTitle: { color: '#34554C', fontWeight: '800', fontSize: 15, marginTop: 13 }, emptyText: { color: '#8A938E', fontSize: 12.5, marginTop: 5 },
  txRow: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', padding: 13, marginBottom: 9, borderRadius: 17, borderWidth: 1, borderColor: '#EAEBE7' }, txIcon: { width: 43, height: 43, borderRadius: 14, alignItems: 'center', justifyContent: 'center' }, txCopy: { flex: 1, marginLeft: 11 }, txTitle: { color: '#263E37', fontSize: 14, fontWeight: '700' }, txMeta: { color: '#919992', fontSize: 11.5, marginTop: 4 }, txAmount: { color: '#263E37', fontWeight: '800', fontSize: 14 },
  amountCard: { backgroundColor: '#FFF', borderRadius: 23, padding: 20, borderWidth: 1, borderColor: '#E7E9E3' }, inputLabel: { color: '#76817C', fontSize: 12, fontWeight: '600' }, amountLine: { flexDirection: 'row', alignItems: 'center', marginTop: 5 }, bigCurrency: { fontSize: 25, fontWeight: '700', color: '#345A4F', marginRight: 7 }, amountInput: { flex: 1, color: '#183D34', fontSize: 39, fontWeight: '800', paddingVertical: 4, letterSpacing: -1 }, formLabel: { color: '#52635D', fontSize: 13, fontWeight: '800', marginTop: 23, marginBottom: 10 },
  categoryGrid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' }, category: { width: '31.5%', backgroundColor: '#FFF', borderRadius: 18, alignItems: 'center', paddingVertical: 13, marginBottom: 10, borderWidth: 1.5, borderColor: '#E8EAE5', position: 'relative' }, categorySelected: { borderColor: '#326C5C', backgroundColor: '#F0F7F3' }, categoryIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' }, categoryText: { color: '#65716B', fontSize: 12, fontWeight: '700', marginTop: 7 }, categoryTextSelected: { color: '#285E50' }, check: { position: 'absolute', top: 7, right: 7, backgroundColor: '#326C5C', width: 17, height: 17, borderRadius: 9, alignItems: 'center', justifyContent: 'center' },
  field: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', borderWidth: 1, borderColor: '#E4E7E1', borderRadius: 15, paddingHorizontal: 15, marginBottom: 10 }, fieldInput: { flex: 1, height: 51, marginLeft: 10, fontSize: 14, color: '#2C453D' }, primary: { height: 55, borderRadius: 17, backgroundColor: '#214E42', flexDirection: 'row', alignItems: 'center', justifyContent: 'center', marginTop: 14 }, primaryText: { color: '#FFF', fontWeight: '800', fontSize: 16, marginRight: 7 },
  statsRow: { flexDirection: 'row', gap: 10 }, stat: { flex: 1, backgroundColor: '#FFF', padding: 17, borderRadius: 19, borderWidth: 1, borderColor: '#E6E8E2' }, statLabel: { color: '#858F89', fontSize: 11.5, marginBottom: 7 }, statValue: { color: '#1F453A', fontWeight: '800', fontSize: 18 },
  budgetBox: { backgroundColor: '#E5EFEA', borderRadius: 19, padding: 17, marginTop: 11, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }, budgetLabel: { color: '#658078', fontSize: 11.5 }, budgetValue: { color: '#244E42', fontSize: 20, fontWeight: '800', marginTop: 4 }, editButton: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#FFF', paddingVertical: 8, paddingHorizontal: 11, borderRadius: 11 }, editText: { color: '#285E50', fontSize: 12, fontWeight: '700', marginLeft: 4 }, budgetEdit: { flexDirection: 'row', marginTop: 9 }, budgetInput: { flex: 1, height: 47, backgroundColor: '#FFF', borderRadius: 13, borderWidth: 1, borderColor: '#DDE2DC', paddingHorizontal: 14, color: '#244E42', fontSize: 16, fontWeight: '700' }, saveSmall: { width: 72, marginLeft: 8, borderRadius: 13, backgroundColor: '#214E42', alignItems: 'center', justifyContent: 'center' }, saveSmallText: { color: '#FFF', fontWeight: '800' },
  connectCard: { backgroundColor: '#FFF', borderRadius: 20, padding: 17, marginTop: 12, borderWidth: 1, borderColor: '#E5E8E2' }, connectHead: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }, connectStatus: { flexDirection: 'row', alignItems: 'center', backgroundColor: '#F2F3F0', borderRadius: 99, paddingHorizontal: 9, paddingVertical: 5 }, connectStatusOn: { backgroundColor: '#E6F3EC' }, statusDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#9DA39F', marginRight: 6 }, statusDotOn: { backgroundColor: '#2F9569' }, connectStatusText: { color: '#7B847F', fontSize: 10.5, fontWeight: '700' }, connectStatusTextOn: { color: '#287354' }, connectTitle: { color: '#23483D', fontSize: 17, fontWeight: '800', marginTop: 14 }, connectText: { color: '#7A857F', fontSize: 12, lineHeight: 18, marginTop: 6 }, payRows: { marginTop: 14, borderTopWidth: 1, borderTopColor: '#EEF0EC' }, payItem: { flexDirection: 'row', alignItems: 'center', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#EEF0EC' }, payIcon: { width: 35, height: 35, borderRadius: 11, alignItems: 'center', justifyContent: 'center' }, payName: { flex: 1, color: '#3A5048', fontSize: 13, fontWeight: '700', marginLeft: 10 }, payTag: { color: '#929A95', fontSize: 11 }, connectButton: { backgroundColor: '#244F43', height: 47, borderRadius: 14, marginTop: 14, flexDirection: 'row', alignItems: 'center', justifyContent: 'center' }, connectButtonText: { color: '#FFF', fontSize: 13.5, fontWeight: '800', marginRight: 5 },
  chartCard: { backgroundColor: '#FFF', padding: 16, borderRadius: 20, borderWidth: 1, borderColor: '#E7E9E4' }, barRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 8 }, barLabel: { width: 55, flexDirection: 'row', alignItems: 'center' }, dot: { width: 7, height: 7, borderRadius: 4, marginRight: 6 }, barName: { color: '#50615B', fontSize: 12 }, barTrack: { flex: 1, height: 8, backgroundColor: '#EEF0EC', borderRadius: 5, overflow: 'hidden' }, barFill: { height: '100%', borderRadius: 5 }, barValue: { width: 76, textAlign: 'right', color: '#42574F', fontSize: 11.5, fontWeight: '700' }, insight: { flexDirection: 'row', backgroundColor: '#ECF3EF', padding: 16, borderRadius: 18, marginTop: 13 },
  nav: { height: Platform.OS === 'ios' ? 78 : 70, backgroundColor: '#FFF', borderTopWidth: 1, borderTopColor: '#E6E8E3', flexDirection: 'row', alignItems: 'center', justifyContent: 'space-around', paddingBottom: Platform.OS === 'ios' ? 8 : 0 }, navItem: { width: 80, alignItems: 'center', justifyContent: 'center' }, navText: { color: '#8A948F', fontSize: 10.5, marginTop: 3, fontWeight: '600' }, navTextActive: { color: '#214E42', fontWeight: '800' }, addNav: { width: 72, height: 55, marginTop: -22, backgroundColor: '#214E42', borderRadius: 20, alignItems: 'center', justifyContent: 'center', shadowColor: '#183D34', shadowOpacity: 0.25, shadowRadius: 8, elevation: 7 }, addNavText: { color: '#FFF', fontSize: 9.5, fontWeight: '700', marginTop: -3 },
});
