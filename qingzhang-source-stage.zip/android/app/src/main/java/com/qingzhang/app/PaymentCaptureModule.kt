package com.qingzhang.app

import android.content.ComponentName
import android.content.Intent
import android.provider.Settings
import com.facebook.react.bridge.Promise
import com.facebook.react.bridge.ReactApplicationContext
import com.facebook.react.bridge.ReactContextBaseJavaModule
import com.facebook.react.bridge.ReactMethod

class PaymentCaptureModule(private val context: ReactApplicationContext) : ReactContextBaseJavaModule(context) {
  override fun getName() = "PaymentCapture"

  @ReactMethod
  fun openNotificationSettings() {
    val intent = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    context.startActivity(intent)
  }

  @ReactMethod
  fun isEnabled(promise: Promise) {
    val component = ComponentName(context, PaymentCaptureService::class.java).flattenToString()
    val enabled = Settings.Secure.getString(context.contentResolver, "enabled_notification_listeners").orEmpty()
    promise.resolve(enabled.contains(component, ignoreCase = true))
  }

  @ReactMethod
  fun drainPending(promise: Promise) {
    val prefs = context.getSharedPreferences("payment_capture", android.content.Context.MODE_PRIVATE)
    synchronized(PaymentCaptureService::class.java) {
      val payload = prefs.getString("pending_transactions", "[]") ?: "[]"
      prefs.edit().putString("pending_transactions", "[]").apply()
      promise.resolve(payload)
    }
  }
}
