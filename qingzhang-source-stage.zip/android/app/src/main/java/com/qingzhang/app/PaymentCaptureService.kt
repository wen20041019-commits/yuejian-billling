package com.qingzhang.app

import android.app.Notification
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class PaymentCaptureService : NotificationListenerService() {
  companion object {
    private const val PREFS = "payment_capture"
    private const val PENDING = "pending_transactions"
    private const val SEEN = "seen_notifications"
    private val supportedPackages = mapOf(
      "com.tencent.mm" to "wechat",
      "com.eg.android.AlipayGphone" to "alipay"
    )
    private val expenseWords = listOf("支付成功", "付款成功", "成功付款", "已付款", "消费", "支出", "扣款")
    private val incomeWords = listOf("收款", "到账", "收入", "退款", "转入")
    private val amountPatterns = listOf(
      Regex("(?:￥|¥|人民币|RMB|金额[：:]?\\s*)(\\d+(?:\\.\\d{1,2})?)", RegexOption.IGNORE_CASE),
      Regex("(\\d+(?:\\.\\d{1,2})?)\\s*元")
    )
  }

  override fun onNotificationPosted(sbn: StatusBarNotification) {
    val source = supportedPackages[sbn.packageName] ?: return
    val extras = sbn.notification.extras
    val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString().orEmpty()
    val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString().orEmpty()
    val bigText = extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString().orEmpty()
    val content = listOf(title, text, bigText).filter { it.isNotBlank() }.distinct().joinToString(" ")

    if (content.isBlank() || incomeWords.any { content.contains(it) }) return
    if (expenseWords.none { content.contains(it) }) return
    val amount = amountPatterns.firstNotNullOfOrNull { pattern ->
      pattern.find(content)?.groupValues?.getOrNull(1)?.toDoubleOrNull()
    } ?: return
    if (amount <= 0) return

    val fingerprint = sha256("${sbn.packageName}|${sbn.key}|$content|$amount")
    val prefs = getSharedPreferences(PREFS, MODE_PRIVATE)
    synchronized(PaymentCaptureService::class.java) {
      val seen = prefs.getStringSet(SEEN, emptySet())?.toMutableSet() ?: mutableSetOf()
      if (!seen.add(fingerprint)) return

      val pending = JSONArray(prefs.getString(PENDING, "[]"))
      pending.put(JSONObject().apply {
        put("id", "auto-$fingerprint")
        put("amount", amount)
        put("category", guessCategory(content))
        put("note", cleanNote(content, source))
        put("date", SimpleDateFormat("yyyy-MM-dd", Locale.CHINA).format(Date()))
        put("createdAt", sbn.postTime)
        put("source", source)
      })
      while (pending.length() > 50) pending.remove(0)
      while (seen.size > 300) seen.remove(seen.first())
      prefs.edit().putString(PENDING, pending.toString()).putStringSet(SEEN, seen).apply()
    }
  }

  private fun guessCategory(text: String): String = when {
    listOf("餐", "外卖", "咖啡", "奶茶", "美团", "饿了么").any { text.contains(it) } -> "餐饮"
    listOf("打车", "地铁", "公交", "滴滴", "出行", "车费").any { text.contains(it) } -> "交通"
    listOf("房租", "物业", "水费", "电费", "燃气").any { text.contains(it) } -> "居住"
    listOf("电影", "游戏", "视频", "娱乐").any { text.contains(it) } -> "娱乐"
    listOf("商店", "超市", "淘宝", "京东", "拼多多").any { text.contains(it) } -> "购物"
    else -> "其他"
  }

  private fun cleanNote(text: String, source: String): String {
    val brand = if (source == "wechat") "微信支付" else "支付宝"
    val cleaned = text.replace(Regex("\\s+"), " ").trim()
    return if (cleaned.length <= 28) cleaned else "$brand 自动记账"
  }

  private fun sha256(value: String): String = MessageDigest.getInstance("SHA-256")
    .digest(value.toByteArray()).joinToString("") { "%02x".format(it) }.take(24)
}
